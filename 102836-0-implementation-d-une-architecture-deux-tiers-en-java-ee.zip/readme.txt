Implémentation d'une architecture deux tiers en Java EE-------------------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/102836-implementation-d-une-architecture-deux-tiers-en-java-eeAuteur  : KXDate    : 12/11/2018
Licence :
=========

Ce document intitul� � Implémentation d'une architecture deux tiers en Java EE � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Ci dessous le code de l'article <a href='https://www.commentcamarche.com/faq/507
71-implementation-d-une-architecture-deux-tiers-en-java-ee'>Implémentation d'un
e architecture deux tiers en Java EE</a>
<br />
<br />Compilation avec la comm
ande Maven suivante (70 Mo d'espace requis)
<br /><pre class="code" data-mode="
java">mvn clean install</pre>
<br />Exécution avec la commande Maven <pre clas
s="code inline inline-code" data-mode="java">mvn exec:java</pre> ou directement 
en Java :
<br /><pre class="code" data-mode="java">java -jar ccm-kx-server-jar-
with-dependencies.jar</pre>
<br />Pour arrêter le serveur, il faut appuyer sur
 Entrée dans la ligne de commande.
<br />
<br />Exemples d'utilisation avec u
n navigateur web :
<br />
<br />Liste des utilisateurs (renvoie la liste des l
ogin)
<br /><a href='http://localhost:8080/user/list' rel='noopener  noreferrer
' target='_blank'>http://localhost:8080/user/list</a>
<br />
<br />Modificatio
n du mot de passe de l'administrateur (renvoie null)
<br /><a href='http://loca
lhost:8080/user/updatePassword?userLogin=admin&userPassword=admin&newPassword=AD
MIN' rel='noopener  noreferrer' target='_blank'>http://localhost:8080/user/updat
ePassword?userLogin=admin&userPassword=admin&newPassword=ADMIN</a>
<br />
<br 
/>Création d'un nouvel utilisateur par l'administrateur  (renvoie null)
<br />
<a href='http://localhost:8080/user/create?userLogin=admin&userPassword=ADMIN&ne
wLogin=toto&newPassword=123456' rel='noopener  noreferrer' target='_blank'>http:
//localhost:8080/user/create?userLogin=admin&userPassword=ADMIN&newLogin=toto&ne
wPassword=123456</a>
<br />
<br />Pour manipuler directement la base de donné
es vous pouvez lancer la console H2 comme ceci :
<br /><pre class="code" data-m
ode="java">java -cp ccm-kx-server-jar-with-dependencies.jar org.h2.tools.Console
</pre>
<br />Avec les même paramètres que celui du fichier persistence.xml :

<br />- Pilote → org.h2.Driver
<br />- URL → jdbc:h2:file:C:h2ccm.kx.serve
r.h2
<br />- Utilisateur → admin
<br />- Mot de passe → admin
<br />
<br
 />Erreur fréquente :
<br />Lors de l'utilisation du programme, vous pourriez 
avoir cette erreur au démarrage :
<br />
<br /><pre class="code" data-mode="j
ava">java.lang.ExceptionInInitializerError
Caused by: org.hibernate.service.spi.
ServiceException: Unable to create requested service [org.hibernate.engine.jdbc.
env.spi.JdbcEnvironment]
Caused by: org.hibernate.HibernateException: Access to 
DialectResolutionInfo cannot be null when &apos;hibernate.dialect&apos; not set<
/pre>
<br />Ce message apparaît lorsque le fichier de la base de donnée est d
éjà utilisé, soit par une autre instance de serveur, soit par la console H2.
